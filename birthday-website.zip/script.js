const gameArea = document.getElementById('gameArea');

function startTicTacToe() {
    gameArea.innerHTML = `
        <h2>Tic Tac Toe</h2>
        <div id="board" style="display:grid; grid-template-columns:100px 100px 100px; gap:5px;"></div>
        <p id="winner"></p>
    `;

    const board = document.getElementById('board');
    let cells = [];
    let turn = 'X';
    let moves = 0;

    for (let i=0; i<9; i++) {
        let cell = document.createElement('button');
        cell.style.height = '100px';
        cell.style.fontSize = '30px';
        cell.onclick = () => {
            if(cell.innerText===''){
                cell.innerText = turn;
                moves++;
                if(checkWinner()){
                    document.getElementById('winner').innerText = `${turn} Wins! 🎉`;
                    disableBoard();
                } else if(moves===9){
                    document.getElementById('winner').innerText = `It's a Tie! 🤝`;
                } else {
                    turn = turn==='X' ? 'O' : 'X';
                }
            }
        }
        board.appendChild(cell);
        cells.push(cell);
    }

    function checkWinner() {
        const winCombos = [
            [0,1,2],[3,4,5],[6,7,8],
            [0,3,6],[1,4,7],[2,5,8],
            [0,4,8],[2,4,6]
        ];
        return winCombos.some(combo => 
            cells[combo[0]].innerText === turn &&
            cells[combo[1]].innerText === turn &&
            cells[combo[2]].innerText === turn
        );
    }

    function disableBoard() {
        cells.forEach(cell => cell.disabled = true);
    }
}

function startSnake() {
    gameArea.innerHTML = `<h2>Snake Game</h2><canvas id="snakeCanvas" width="300" height="300" style="border:1px solid #333;"></canvas>`;
    const canvas = document.getElementById('snakeCanvas');
    const ctx = canvas.getContext('2d');

    const grid = 15;
    let snake = [{x:150, y:150}];
    let dx = grid;
    let dy = 0;
    let apple = {x: 75, y: 75};

    document.addEventListener('keydown', e => {
        if(e.key==='ArrowUp' && dy===0){ dx=0; dy=-grid; }
        if(e.key==='ArrowDown' && dy===0){ dx=0; dy=grid; }
        if(e.key==='ArrowLeft' && dx===0){ dx=-grid; dy=0; }
        if(e.key==='ArrowRight' && dx===0){ dx=grid; dy=0; }
    });

    function gameLoop(){
        ctx.clearRect(0,0,300,300);
        let head = {x: snake[0].x + dx, y: snake[0].y + dy};
        snake.unshift(head);
        if(head.x === apple.x && head.y === apple.y){
            apple = {x: Math.floor(Math.random()*20)*grid, y: Math.floor(Math.random()*20)*grid};
        } else {
            snake.pop();
        }
        if(head.x<0||head.y<0||head.x>=300||head.y>=300 || snake.slice(1).some(s=>s.x===head.x && s.y===head.y)){
            alert("Game Over! Reload page to play again.");
            return;
        }
        ctx.fillStyle = 'red';
        ctx.fillRect(apple.x, apple.y, grid, grid);
        ctx.fillStyle = 'green';
        snake.forEach(s=> ctx.fillRect(s.x, s.y, grid-1, grid-1));
        setTimeout(gameLoop, 150);
    }
    gameLoop();
}

function startBalloonPop() {
    gameArea.innerHTML = `<h2>Balloon Pop 🎈</h2><canvas id="balloonCanvas" width="300" height="400" style="border:1px solid #333;"></canvas>`;
    const canvas = document.getElementById('balloonCanvas');
    const ctx = canvas.getContext('2d');
    let balloons = [];
    function createBalloons(){
        for(let i=0;i<5;i++){
            balloons.push({x:Math.random()*250, y:400, radius:20});
        }
    }
    document.addEventListener('click', e=>{
        const rect = canvas.getBoundingClientRect();
        const mx = e.clientX - rect.left;
        const my = e.clientY - rect.top;
        balloons = balloons.filter(b=> !(Math.hypot(b.x-mx,b.y-my)<b.radius));
    });
    function draw(){
        ctx.clearRect(0,0,300,400);
        balloons.forEach(b=>{
            ctx.beginPath();
            ctx.fillStyle='pink';
            ctx.arc(b.x, b.y, b.radius,0,Math.PI*2);
            ctx.fill();
            b.y-=2;
        });
        requestAnimationFrame(draw);
    }
    createBalloons();
    draw();
}